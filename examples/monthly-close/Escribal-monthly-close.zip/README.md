# Monthly close — an example you can run

This folder is a real Escribal workflow, and a large one. From three CSV files (sales, expenses and
the budget) it writes the pack a finance team puts together every month: a **workbook**, a
**board deck**, a **one-page PDF summary** and a **report**, all four with the same
look and the same figures. It is about 800 instructions, and the notes on the canvas explain it from
the inside.

The company (*Norvale Group*) and its figures are made up.

## How to run it

1. **Unzip into Documents**, so that you end up with the folder `Documents\Escribal-monthly-close`
   holding `Monthly-close.scriba` and the three CSV files. The name matters: it is the folder the
   workflow names.
2. **Open `Monthly-close.scriba`** in Escribal and press **Run**.
3. Four documents appear beside them: `Management-report-September.xlsx`,
   `Board-deck-September.pptx`, `Executive-summary-September.pdf` and
   `Management-report-September.docx`.

If the folder ended up somewhere else, the run stops **without writing anything** and tells you
exactly where it looked.

## Make it yours

Everything you would change is at the top of the canvas, under three notes:

- **Settings**: the company, the month, the year, who prepares the pack and the alert threshold.
- **Settings, the color palette**: the five brand colors and the two text colors.
- **Settings, the font**: one font for the deck, the PDF summary and the report.

Change a color and run again: all four documents follow. Change the threshold (4 by default, a
percentage) and the watch list changes with it: it holds every region that fell short of its budget
and every department that went over it by more than that.

To run it next month, replace the three CSV files with the new ones, with the same file names,
change the month in the settings and press Run. The documents come out named after the month.

## What the canvas does, top to bottom

1. **The settings and the data.** The three CSV files are read, grouped by region, by product line
   and by department, and each set against its budget. Two lists come out of this that all four
   documents use: the income statement in five lines and the watch list.
2. **The workbook.** Five sheets. The look is set once, by a loop over the sheet names; then
   each sheet is filled, with live formulas, charts and the rows past the threshold picked out.
3. **The board deck.** One slide is a template (title, rule and footer) and the others are copies
   of it. The cards and the slide for each region are made by loops.
4. **The PDF summary.** The band and the tiles at the top are drawn at exact positions; the rest
   flows down the page.
5. **The report.** Four styles, the tables filled by loops and, at the end, one font and one
   spacing for the whole document.

## What is in the folder

| File | What it is |
|---|---|
| `Monthly-close.scriba` | The workflow. This is what you open in Escribal. |
| `sales.csv` | Made-up sales: revenue, cost and units by region and product line. |
| `expenses.csv` | Made-up expenses: what each department spent, by category. |
| `budget.csv` | The budget for the month: the regions, the cost of goods and the departments. |
| `README.md` | This file. |
| `LICENSE.txt` | The MIT license: use the example as a template and change it however you like. |

The paths inside the workflow are portable: there is no folder from the machine it was built on, so
it works on yours without changing anything.
