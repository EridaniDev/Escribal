# Monthly account statement — an example you can run

This folder is a real Escribal workflow. From a CSV of invoices it writes a **Word document** with
one line per customer and an **Excel sheet with a chart**. It is 29 instructions and four notes that
explain the canvas from the inside.

## How to run it

1. **Unzip into Documents**, so that you end up with the folder `Documents\Escribal-example` holding
   `Account-statement.scriba` and `invoices-september.csv`. The name matters: it is the folder the
   workflow names.
2. **Open `Account-statement.scriba`** in Escribal and press **Run**.
3. `Account-statement-September.docx` and `Summary-September.xlsx` appear beside them.

To run it again next month, replace the CSV with the new one — same file name — and press Run again.
That is all there is to it, and it is what the program is about.

If the folder ended up somewhere else, the run stops **without writing anything** and tells you
exactly where it looked.

## What the canvas does, top to bottom

1. **The data is read** — the CSV with its headers, its rows, and a *Group and aggregate* that adds
   up what each customer was billed. The CSV is closed without saving: the original is not touched.
2. **The Word document is built** — title, a subtitle with today's date, and counts taken from the
   file itself (*12 invoices · 5 customers*), which is what shows the numbers come from the data and
   are not typed in by hand.
3. **A loop over customers** — it formats the amount (`$22,500.00`), writes that customer's line,
   builds up the summary table, and a **condition** adds a notice to anyone over $20,000. With this
   data it fires on two of the five.
4. **The Excel sheet is built** — the whole table in one go, a calculation so the range reaches the
   last customer, the number format, and a **bar chart**.

## What is in the folder

| File | What it is |
|---|---|
| `Account-statement.scriba` | The workflow. This is what you open in Escribal. |
| `invoices-september.csv` | The source data, made up: 12 invoices from 5 customers. |
| `README.md` | This file. |

The paths inside the workflow are portable: there is no folder from the machine it was built on, so
it works on yours without changing anything.
